from pathlib import Path

import pandas as pd


REFERENCE_STANDARDS_CANDIDATES = [
    Path(__file__).resolve().parent.parent / "standards_manager" / "EA" / "data" / "ea_RS.csv",
    Path(__file__).resolve().parent.parent / "standards_manager" / "data" / "ea_RS.csv",
    Path(__file__).resolve().parent.parent / "standards_manager" / "data" / "EA_standards.csv",
]


def label_element_type(df: pd.DataFrame) -> pd.DataFrame:
    """Label each EA peak by the isotope channel it populated."""
    out = df.copy()
    out['Element Type'] = pd.Series([None] * len(out), dtype=object)
    out.loc[out['d 15N/14N'].notna(), 'Element Type'] = 'Nitrogen'
    out.loc[out['d 13C/12C'].notna(), 'Element Type'] = 'Carbon'
    return out


def load_ea_standards() -> pd.DataFrame:
    """Load the EA standards table from the package reference CSV."""
    for path in REFERENCE_STANDARDS_CANDIDATES:
        if path.exists():
            return pd.read_csv(path, encoding='unicode_escape')
    raise FileNotFoundError(
        "EA standards file not found. Checked: "
        + ", ".join(str(path) for path in REFERENCE_STANDARDS_CANDIDATES)
    )


def add_seconds_since_start(df: pd.DataFrame) -> pd.DataFrame:
    """Add acquisition datetime and elapsed seconds columns for EA runs."""
    out = df.copy()
    out['Datetime'] = pd.to_datetime(out['Date'] + ' ' + out['Time'], errors='coerce')
    out = out[out['Datetime'].notna()]
    t0 = out['Datetime'].iloc[0]
    out['Seconds Since Start'] = (out['Datetime'] - t0).dt.total_seconds()
    return out


def import_EA_data(file_path) -> pd.DataFrame:
    """Read and minimally normalize a raw EA-IRMS export file."""
    df = pd.read_csv(file_path, encoding='unicode escape')
    df = label_element_type(df)
    df = add_seconds_since_start(df)
    df = df[df['Component'].isin(['N2', 'CO2'])]
    return df
