import pandas as pd
from pathlib import Path
import ipywidgets as widgets
from IPython.display import display, clear_output

HERE       = Path(__file__).resolve().parent
CSV_DIR    = HERE / "utils/vsmow_standards"
CSV_DIR.mkdir(exist_ok=True, parents=True)

# your built‑in defaults
DEFAULT_VSMOW = {
    "dD": {
        "type": ["drift","linearity","linearity","drift"],
        "chain length": ["C18","C20","C28","C24"],
        "isotope value": [-206.2, -166.7, -89.28, -179.3],
        "std": [1.7, 0.3, 1.0627, 1.7],
        "n":   [5, 3, 924, 5],
        "VSMOW accuracy check": ["False","False","False","True"]
    },
    "dC": {
        "type": ["drift","linearity","drift"],
        "chain length": ["C18","C20","C24"],
        "isotope value": [-23.24, -30.68, -26.57],
        "std": [0.01, 0.02, 0.02],
        "n":   [5,    3,    5],
        "VSMOW accuracy check": ["False","False","True"]
    }
}

def _csv_path(isotope: str) -> Path:
    return CSV_DIR / f"vsmow_{isotope}.csv"

def standard_editor(isotope: str="dD") -> pd.DataFrame:
    """
    Step 1: dump defaults (once) and open an in‑cell TextArea + Save button.
    On Save it overwrites the CSV and displays the new table.
    """
    path = _csv_path(isotope)
    # 1) Dump defaults if missing
    if not path.exists():
        df0 = pd.DataFrame(DEFAULT_VSMOW[isotope])
        df0.to_csv(path, index=False)

    # 2) Load CSV as text
    text = path.read_text()
    ta   = widgets.Textarea(
        value=text,
        layout=widgets.Layout(width="100%", height="300px")
    )
    btn  = widgets.Button(description="Save", button_style="success")
    out  = widgets.Output()

    def _on_save(_):
        with out:
            clear_output()
            try:
                # overwrite CSV
                path.write_text(ta.value)
                df_new = pd.read_csv(path)
                display(df_new)
            except Exception as e:
                print("Error saving:", e)

    btn.on_click(_on_save)
    display(ta, btn, out)

    # return whatever is on disk (defaults or just‑saved)
    return pd.read_csv(path)