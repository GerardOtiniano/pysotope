import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import TextBox

def pick_chain_retention(
    drift_df: pd.DataFrame,
    lin_df:   pd.DataFrame,
    sample_df:pd.DataFrame,
    time_col: str        = "time",
    amp_col:  str        = "amp",
    kind_col: str        = "kind",
    kind_map: dict       = None,
    chain_order: list    = None,
    picker_tol: float    = 5,
    textbox_rect: tuple  = (0.25, 0.90, 0.15, 0.05),
    figsize:  tuple      = (8,4)) -> dict:
    """
    Plot drift, linearity, and sample points and let the user click to assign
    chain labels at retention times.  Returns a dict {chain_name: retention_time}.
    
    Parameters
    ----------
    drift_df, lin_df, sample_df
        DataFrames each containing at least [time_col, amp_col].
    time_col, amp_col
        Column names for retention time and signal amplitude.
    kind_col
        Name of the column to add internally that marks 'drift','lin','sample'.
    kind_map
        Optional dict mapping {'drift':color,'lin':color,'sample':color}.
        Defaults to {'drift':'blue','lin':'red','sample':'black'}.
    chain_order
        List of chains in expected elution order, e.g. ['C18','C20','C24','C28'].
        Defaults to ['C18','C20','C24','C28'].
    picker_tol
        The matplotlib “picker” tolerance (in points) for selecting scatter.
    textbox_rect
        (left, bottom, width, height) of the TextBox in figure coords.
    figsize
        Figure size.
    """
    # defaults
    kind_map    = kind_map or {"drift":"blue","lin":"red","sample":"black"}
    chain_order = chain_order or ["C18","C20","C24","C28"]
    
    # 1) build a unified DataFrame
    drift_df  = drift_df.copy();  drift_df[kind_col] = "drift"
    lin_df    = lin_df.copy();    lin_df[kind_col] = "lin"
    sample_df = sample_df.copy(); sample_df[kind_col] = "sample"
    plot_df   = pd.concat([drift_df, lin_df, sample_df], ignore_index=True)
    
    # 2) prep plot
    fig, ax = plt.subplots(figsize=figsize)
    for kind, grp in plot_df.groupby(kind_col):
        ax.scatter(
            grp[time_col], grp[amp_col],
            c=kind_map.get(kind, "gray"),
            label=kind, picker=picker_tol
        )
    ax.set_xlabel("Retention time")
    ax.set_ylabel("Amplitude")
    ax.legend()
    
    # 3) state & order checker
    picked = {}
    def is_order_ok(chain, rt):
        idx = chain_order.index(chain)
        prev = [picked[c] for c in chain_order[:idx] if c in picked]
        nxt  = [picked[c] for c in chain_order[idx+1:] if c in picked]
        if prev and rt <= max(prev): return False
        if nxt  and rt >= min(nxt):  return False
        return True
    
    # 4) interactive callback
    vline = ax.axvline(np.nan, color="gray", ls="--")
    text_ax = None
    
    def on_pick(event):
        nonlocal text_ax
        # remove any previous textbox
        if text_ax:
            text_ax.remove()
            text_ax = None
        ind = event.ind[0]
        rt  = plot_df.iloc[ind][time_col]
        vline.set_xdata(rt)
        fig.canvas.draw_idle()
        
        # spawn the TextBox
        text_ax = plt.axes(textbox_rect)
        tb = TextBox(text_ax, 'Chain: ')
        def submit(text):
            nonlocal text_ax
            chain = text.strip().upper()
            text_ax.remove(); text_ax = None
            fig.canvas.draw_idle()
            
            if chain not in chain_order:
                print(f"⚠ '{chain}' not in {chain_order}")
            elif chain in picked:
                print(f"⚠ '{chain}' already at {picked[chain]:.2f}")
            elif not is_order_ok(chain, rt):
                print(f"⚠ order violation: {chain} @ {rt:.2f}")
            else:
                picked[chain] = rt
                print(f"✅ {chain} → {rt:.2f}")
                if len(picked) == len(chain_order):
                    print("\n🎉 All chains labelled:", picked)
        tb.on_submit(submit)
    
    fig.canvas.mpl_connect("pick_event", on_pick)
    plt.show()
    
    return picked